

hearthcards_url = 'https://hearthcards.net/'
